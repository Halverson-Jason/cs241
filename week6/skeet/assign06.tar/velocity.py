class Velocity:
    def __init__(self,dx,dy):
        self.dx = dx
        self.dy = dx
    def set_dx(self,dx):
        self.dx = dx
    def set_dy(self,dy):
        self.dy = dy
    def get_dx(self):
        return self.dx
    def get_dy(self):
        return self.dy